import json
import hashlib
import os

DB_FILE = "user_db.json"

def load_users():
    if not os.path.exists(DB_FILE):
        return {}
    with open(DB_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(DB_FILE, "w") as f:
        json.dump(users, f)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username, password):
    users = load_users()
    if username in users:
        print("Error: Username already exists.")
        return

    if not username or not password:
        print("Error: Username and password cannot be empty.")
        return

    users[username] = hash_password(password)
    save_users(users)
    print("Registration successful.")

def login_user(username, password):
    users = load_users()
    hashed_pw = hash_password(password)

    if username not in users:
        print("Error: Username not found.")
    elif users[username] == hashed_pw:
        print("Login successful. Welcome,", username)
    else:
        print("Error: Incorrect password.")
