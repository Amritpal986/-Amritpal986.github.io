from utils import register_user, login_user

def main():
    print("Welcome to the Login and Registration System")
    while True:
        print("\nSelect an option:")
        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Enter choice (1/2/3): ")

        if choice == "1":
            username = input("Enter new username: ")
            password = input("Enter new password: ")
            register_user(username, password)

        elif choice == "2":
            username = input("Enter username: ")
            password = input("Enter password: ")
            login_user(username, password)

        elif choice == "3":
            print("Exiting the program. Goodbye!")
            break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
