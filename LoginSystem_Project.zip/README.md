# Login and Registration System

## Features:
- Registration with username uniqueness check
- Login with hashed password verification
- Secure password storage using SHA-256
- File-based database (JSON)
- Clear success and error messages

## How to Run
1. Ensure Python 3 is installed.
2. Run:
```bash
python main.py
```

## Author:
GitHub: [Amritpal986](https://github.com/Amritpal986)
